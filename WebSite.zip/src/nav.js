/**
 * Get navigation list
 */
export const getNavList = () => {
    let navList = [];

    // Home route
    // navList = navList.concat({
    //     name: "About",
    //     url: "/",
    // });
    // navList = navList.concat({
    //     name: "Home",
    //     url: "/home",
    // });

    // About route
    // navList = navList.concat({
    //     name: "About",
    //     url: "/about",
    // });

    // Resume route
    // navList = navList.concat({
    //     name: "Resume",
    //     url: "/resume",
    // });

    // Portfolio route
    // navList = navList.concat({
    //     name: "Portfolio",
    //     url: "/portfolio",
    // });


    return navList;
}
