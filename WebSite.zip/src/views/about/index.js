import React, { Component } from "react";

import Aboutme from "./innerComponents/AboutMe";

class About extends Component {

    render() {
        return (
            <div>
                <div className="top-content">
                </div>
                <Aboutme />
            </div>
        );
    }
}
export default About;
