import React, { Component } from "react";

class Portfolio extends Component {

    render() {
        return (
            <div>
                <div className="top-content">
                    <h1 className="text-center">Portfolio of Jovial</h1>
                </div>
                <div className="container">
                    <div className="row">
                        <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                            <div className="resume-group">
                                <h3>Projects</h3>
                                <div className="row">
                                    <div className="col-xs-6 col-sm-6 col-md-4 col-lg-3">
                                        <div className="resume-group">
                                            <h3>Todo</h3>
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Portfolio;
