import React, { Component } from "react";

class Home extends Component {

    render() {
        return (
            <div>
                <div className="top-content">
                    <h1>Home</h1>
                </div>
                <div className="container">
                    <div className="row">
                        <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                            <div className="developer">

                            </div>
                        </div>
                        <div className="col-xs-12 col-sm-6 col-md-6 col-lg-6"></div>
                    </div>
                </div>
            </div>
        );
    }
}
export default Home;
