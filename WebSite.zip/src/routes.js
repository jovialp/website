export const routes = [
    {
        ex:"a"
    }
];
